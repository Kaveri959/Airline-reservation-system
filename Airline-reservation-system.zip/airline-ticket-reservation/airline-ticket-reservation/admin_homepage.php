<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome Administrator</title>
    <link rel="stylesheet" type="text/css" href="css/style.css" />
    <link rel="stylesheet" href="font-awesome-4.7.0\css\font-awesome.min.css">
    <style>
        .container img {
            width: 100vw;
            height: auto;
            display: block;
            position: absolute;
            top: 0;
            left: 0;
            opacity: 0.2; /* Adjust the opacity as needed (0 to 1) */
            z-index: -1;
        }

        h2 {
            color: black; /* Set text color */
            padding: 10px; /* Add padding for better visibility */
            display: inline-block; /* Prevent full width */
        }

        table {
            width: 80%;
            margin: 20px auto;
            border-collapse: collapse;
        }

        table, th, td {
            border: 1px solid bLack;
            text-align: left;
        }

        th, td {
            padding: 15px;
        }

        .admin_func a {
            color: black; /* Set link text color */
        }

        .admin_func a:hover {
            text-decoration: underline;
        }
    </style>
</head>

<body>
    <img class="logo" src="images/shutterstock_22.jpg" />
	<h1 id="title" style="color: darkblue;" >
			Airline Reservation System
		</h1>
    <div>
        <ul>
            <li><a href="admin_homepage.php"><i class="fa fa-home" aria-hidden="true"></i> Home</a></li>
            <li><a href="admin_homepage.php"><i class="fa fa-desktop" aria-hidden="true"></i> Dashboard</a></li>
            <li><a href="logout_handler.php"><i class="fa fa-sign-out" aria-hidden="true"></i> Logout</a></li>
        </ul>
    </div>
    <h2>Welcome Administrator!</h2>
    <table>
        <tr>
            <td class="admin_func"><a href="admin_view_booked_tickets.php"><i class="fa fa-plane" aria-hidden="true"></i>
                    View List of Booked Tickets for a Flight</a>
            </td>
        </tr>
        <tr>
            <td class="admin_func"><a href="add_flight_details.php"><i class="fa fa-plane" aria-hidden="true"></i>
                    Add Flight Schedule Details</a>
            </td>
        </tr>
        <tr>
            <td class="admin_func"><a href="delete_flight_details.php"><i class="fa fa-plane" aria-hidden="true"></i>
                    Delete Flight Schedule Details</a>
            </td>
        </tr>
    </table>
    <div class="container">
        <img src="images/air.jpg" width="100%" style="display: block;">
    </div>
</body>

</html>
